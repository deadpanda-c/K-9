Dr Who K9 by 134B29F on Thingiverse: https://www.thingiverse.com/thing:6299820

Summary:
K9 from Dr WhoNew Head and body to accommodate wheels